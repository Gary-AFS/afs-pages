// AFS RRP Radar — content script (runs inside the Shopify admin).
// Read-only. Detects draft-order / order line items, asks the service worker for
// RRP (compare-at) vs promo pricing, and annotates each line + a floating summary.
//
// The line-item detection is deliberately selector-agnostic (Shopify's admin is a
// Polaris SPA whose class names churn): it keys off product links + a nearby price,
// not brittle CSS classes. If a future admin layout changes, the CONFIG below and
// findLineRows() are the two places to adjust. A manual "Rescan" button in the
// summary panel + verbose console logging (see DEBUG) make tuning quick.

(function () {
  'use strict';

  const CONFIG = {
    // Only activate on the draft-order / order editor, not every admin page.
    pathTest: /\/(draft_orders|orders)(\/|$)/,
    debug: false, // flip true (or set localStorage['afsrrp:debug']='1') for console tracing
    badgeAttr: 'data-afsrrp',
    rescanDebounceMs: 700
  };

  const DEBUG = () => CONFIG.debug || localStorage.getItem('afsrrp:debug') === '1';
  const log = (...a) => { if (DEBUG()) console.log('%c[AFS RRP]', 'color:#f26422;font-weight:bold', ...a); };

  const money = (c, cur) => (window.AFSRRP ? window.AFSRRP.money(c, cur) : '$' + (c / 100).toFixed(2));
  const pct = (r, p) => (window.AFSRRP ? window.AFSRRP.pct(r, p) : null);

  let enabled = true;
  let currency = 'AUD';
  let summaryEl = null;
  let observer = null;
  let debounceTimer = null;
  const seen = new WeakSet(); // rows already annotated this pass

  // ---- store detection -----------------------------------------------------
  function currentStore() {
    // https://admin.shopify.com/store/{handle}/draft_orders/123
    let m = location.pathname.match(/\/store\/([^/]+)\//);
    if (m) return m[1];
    // legacy {handle}.myshopify.com/admin/...
    m = location.hostname.match(/^([^.]+)\.myshopify\.com$/);
    if (m) return m[1];
    return null;
  }

  function onDraftOrderPage() {
    return CONFIG.pathTest.test(location.pathname);
  }

  // ---- line-item detection (selector-agnostic) -----------------------------
  function findLineRows() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/products/"]'));
    const rows = new Map();
    anchors.forEach(a => {
      const href = a.getAttribute('href') || '';
      // product links inside the admin; capture the numeric product id when present
      const idM = href.match(/\/products\/(\d+)/);
      const title = (a.textContent || '').trim();
      if (!title || title.length < 2) return;

      // walk up to the smallest ancestor that also contains a currency amount —
      // that block is the "line" we annotate.
      let el = a, row = null, hops = 0;
      while (el && hops < 9) {
        el = el.parentElement; hops++;
        if (!el) break;
        if (/\$\s?\d/.test(el.textContent) && el.querySelectorAll('a[href*="/products/"]').length <= 2) {
          row = el; break;
        }
      }
      row = row || a.closest('li, tr, [role="row"], div');
      if (!row || rows.has(row)) return;
      rows.set(row, { row, anchor: a, productId: idM ? idM[1] : null, title });
    });
    return Array.from(rows.values());
  }

  function extractRow(info) {
    const text = info.row.textContent || '';
    const skuM = text.match(/SKU[:\s]+([A-Za-z0-9._\/\-]+)/i);
    const priceM = text.match(/\$\s?([\d,]+(?:\.\d{2})?)/);
    let priceCents = null;
    if (priceM) priceCents = Math.round(parseFloat(priceM[1].replace(/,/g, '')) * 100);
    // best-effort variant text: a small element right after the product anchor
    let variantTitle = '';
    const sib = info.anchor.parentElement ? info.anchor.parentElement.nextElementSibling : null;
    if (sib && sib.textContent && sib.textContent.trim().length < 40) variantTitle = sib.textContent.trim();
    return { title: info.title, sku: skuM ? skuM[1] : '', variantTitle, priceCents, productId: info.productId };
  }

  // ---- badge rendering -----------------------------------------------------
  function badgeFor(row) {
    let b = row.querySelector(':scope > .afsrrp-badge');
    if (!b) {
      b = document.createElement('span');
      b.className = 'afsrrp-badge';
      // place at end of the row's first text-bearing block
      row.appendChild(b);
    }
    return b;
  }

  function renderPending(row) {
    const b = badgeFor(row);
    b.className = 'afsrrp-badge pending';
    b.textContent = 'checking price…';
  }

  function renderResult(row, res) {
    const b = badgeFor(row);
    if (!res || !res.ok) {
      b.className = 'afsrrp-badge unknown';
      b.textContent = 'no live price';
      b.title = (res && res.reason) ? res.reason : 'Could not match this line to a storefront product';
      return null;
    }
    if (res.onSale) {
      const p = pct(res.rrp, res.promo);
      b.className = 'afsrrp-badge sale';
      b.innerHTML = '<strong>ON SALE</strong> was ' + money(res.rrp, res.currency || currency) +
        ' &middot; save ' + money(res.saving, res.currency || currency) + (p != null ? ' (' + p + '%)' : '');
      b.title = 'Matched by ' + res.matchedBy + ' → ' + (res.productTitle || '') +
        (res.variantTitle && res.variantTitle !== 'Default Title' ? ' / ' + res.variantTitle : '');
      return { rrp: res.rrp, promo: res.promo, saving: res.saving, onSale: true };
    }
    b.className = 'afsrrp-badge full';
    b.textContent = 'not on sale';
    b.title = 'RRP = current price (' + money(res.promo, res.currency || currency) + '), matched by ' + res.matchedBy;
    return { rrp: res.rrp != null ? res.rrp : res.promo, promo: res.promo, saving: 0, onSale: false };
  }

  // ---- summary panel -------------------------------------------------------
  function ensureSummary() {
    if (summaryEl && document.body.contains(summaryEl)) return summaryEl;
    summaryEl = document.createElement('div');
    summaryEl.className = 'afsrrp-summary';
    summaryEl.innerHTML =
      '<div class="afsrrp-head">' +
        '<span class="afsrrp-dot"></span><span class="afsrrp-title">RRP Radar</span>' +
        '<button class="afsrrp-btn afsrrp-rescan" title="Re-scan the line items">Rescan</button>' +
        '<button class="afsrrp-btn afsrrp-hide" title="Hide">&times;</button>' +
      '</div>' +
      '<div class="afsrrp-body"><div class="afsrrp-empty">Scanning line items…</div></div>';
    document.body.appendChild(summaryEl);
    summaryEl.querySelector('.afsrrp-rescan').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'clearCache' }, () => scan(true));
    });
    summaryEl.querySelector('.afsrrp-hide').addEventListener('click', () => {
      summaryEl.classList.add('afsrrp-collapsed');
    });
    summaryEl.querySelector('.afsrrp-head').addEventListener('click', (e) => {
      if (e.target.closest('.afsrrp-btn')) return;
      summaryEl.classList.toggle('afsrrp-collapsed');
    });
    return summaryEl;
  }

  function renderSummary(stats) {
    const el = ensureSummary();
    const body = el.querySelector('.afsrrp-body');
    if (!stats.lines) {
      body.innerHTML = '<div class="afsrrp-empty">No line items detected yet. Add a product, then Rescan.</div>';
      return;
    }
    const rows = [
      ['Lines scanned', String(stats.lines)],
      ['On sale', String(stats.onSale)],
      ['Total RRP', money(stats.totalRRP, currency)],
      ['Total now', money(stats.totalPromo, currency)]
    ];
    let html = rows.map(r => '<div class="afsrrp-row"><span>' + r[0] + '</span><span>' + r[1] + '</span></div>').join('');
    html += '<div class="afsrrp-row afsrrp-saving"><span>Customer saves</span><span>' +
      money(stats.totalSaving, currency) + '</span></div>';
    if (stats.unknown) html += '<div class="afsrrp-note">' + stats.unknown + ' line(s) had no live price match</div>';
    body.innerHTML = html;
  }

  // ---- main scan -----------------------------------------------------------
  function scan(force) {
    if (!enabled || !onDraftOrderPage()) { if (summaryEl) summaryEl.remove(), summaryEl = null; return; }
    const store = currentStore();
    const infos = findLineRows();
    log('scan: store=', store, 'rows=', infos.length, location.pathname);
    ensureSummary();

    const stats = { lines: 0, onSale: 0, totalRRP: 0, totalPromo: 0, totalSaving: 0, unknown: 0 };
    if (!infos.length) { renderSummary(stats); return; }
    if (!store) { renderSummary(stats); return; }

    let pending = infos.length;
    infos.forEach(info => {
      const already = info.row.getAttribute(CONFIG.badgeAttr);
      const details = extractRow(info);
      const key = (details.sku || '') + '|' + details.title + '|' + (details.priceCents || '');
      if (!force && already === key) {
        // reuse cached badge visual; still needs counting — re-request is cheap (worker caches)
      }
      info.row.setAttribute(CONFIG.badgeAttr, key);
      renderPending(info.row);
      chrome.runtime.sendMessage(
        { type: 'resolvePricing', payload: Object.assign({ store }, details) },
        (res) => {
          const r = renderResult(info.row, res);
          if (r) {
            stats.lines += 1;
            if (r.onSale) stats.onSale += 1;
            stats.totalRRP += (r.rrp || r.promo || 0);
            stats.totalPromo += (r.promo || 0);
            stats.totalSaving += (r.saving || 0);
          } else {
            stats.lines += 1;
            stats.unknown += 1;
          }
          pending -= 1;
          if (pending <= 0) renderSummary(stats);
        }
      );
    });
  }

  function scheduleScan() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => scan(false), CONFIG.rescanDebounceMs);
  }

  // ---- observers: SPA route changes + DOM mutations ------------------------
  function watch() {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => scheduleScan());
    observer.observe(document.body, { childList: true, subtree: true });

    // patch history so SPA navigations re-trigger a scan
    ['pushState', 'replaceState'].forEach(fn => {
      const orig = history[fn];
      history[fn] = function () { const r = orig.apply(this, arguments); window.dispatchEvent(new Event('afsrrp:navigate')); return r; };
    });
    window.addEventListener('popstate', () => window.dispatchEvent(new Event('afsrrp:navigate')));
    window.addEventListener('afsrrp:navigate', () => setTimeout(() => scan(true), 400));
  }

  // ---- init ----------------------------------------------------------------
  function init() {
    chrome.storage.sync.get(['enabled', 'currency'], (s) => {
      enabled = s.enabled !== false; // default on
      currency = s.currency || 'AUD';
      log('init enabled=', enabled, 'currency=', currency);
      watch();
      setTimeout(() => scan(true), 600);
    });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.enabled) { enabled = changes.enabled.newValue !== false; scan(true); }
      if (changes.currency) currency = changes.currency.newValue || 'AUD';
    });
    // popup can ask us to rescan
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'rescan') { chrome.runtime.sendMessage({ type: 'clearCache' }, () => scan(true)); }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
