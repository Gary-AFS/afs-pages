// AFS RRP Radar — content script (runs inside the Shopify admin).
// Read-only. Detects draft-order / order line items, asks the service worker for
// RRP (compare-at) vs promo pricing, and annotates each line + a floating summary.
//
// v0.2 — the modern Shopify admin renders the order editor as `s-*` web components
// inside deeply nested Shadow DOM, and product line links are <s-internal-link>
// custom elements (not <a>) with href /products/{id}/variants/{variantId}. So we:
//   1) pierce shadow roots when scanning (a flat querySelectorAll can't see them),
//   2) match any element with a /products/{id} href (not just <a>),
//   3) read the variantId straight off the href → exact storefront match,
//   4) inline-style the per-line badges (injected content.css can't cross the
//      shadow boundary, so external classes wouldn't apply inside a line row).
// The floating summary panel lives in the light DOM, so content.css still styles it.
//
// Because Shadow-DOM mutations don't bubble to a document observer, we also poll on
// a low-frequency interval as a safety net. A manual "Rescan" button + verbose
// logging (see DEBUG) make tuning quick.

(function () {
  'use strict';

  const CONFIG = {
    // Only activate on the draft-order / order editor, not every admin page.
    pathTest: /\/(draft_orders|orders)(\/|$)/,
    debug: false, // flip true (or set localStorage['afsrrp:debug']='1') for console tracing
    badgeAttr: 'data-afsrrp',
    rescanDebounceMs: 500,
    pollMs: 2000
  };

  const DEBUG = () => CONFIG.debug || localStorage.getItem('afsrrp:debug') === '1';
  const log = (...a) => { if (DEBUG()) console.log('%c[AFS RRP]', 'color:#f26422;font-weight:bold', ...a); };

  const money = (c, cur) => (window.AFSRRP ? window.AFSRRP.money(c, cur) : '$' + (c / 100).toFixed(2));
  const pct = (r, p) => (window.AFSRRP ? window.AFSRRP.pct(r, p) : null);

  let enabled = true;
  let currency = 'AUD';
  let summaryEl = null;
  let observer = null;
  let debounceTimer = null;
  let pollTimer = null;

  // ---- shadow-piercing query ----------------------------------------------
  // Collect every element (across open shadow roots) for which pred() is true.
  function deepQueryAll(pred, root, out, roots) {
    root = root || document;
    out = out || [];
    roots = roots || new Set();
    let nodes;
    try { nodes = root.querySelectorAll('*'); } catch (e) { return out; }
    for (const el of nodes) {
      try { if (pred(el)) out.push(el); } catch (e) { /* ignore */ }
      if (el.shadowRoot && !roots.has(el.shadowRoot)) {
        roots.add(el.shadowRoot);
        deepQueryAll(pred, el.shadowRoot, out, roots);
      }
    }
    return out;
  }

  // Parent that may cross a shadow boundary (element → its host).
  function parentAcrossShadow(el) {
    if (el.parentElement) return el.parentElement;
    const root = el.getRootNode && el.getRootNode();
    return (root instanceof ShadowRoot) ? root.host : null;
  }

  const PRICE_RE = /\$\s?[\d,]+\.\d{2}/;

  // ---- store detection -----------------------------------------------------
  function currentStore() {
    // https://admin.shopify.com/store/{handle}/draft_orders/123
    let m = location.pathname.match(/\/store\/([^/]+)\//);
    if (m) return m[1];
    // legacy {handle}.myshopify.com/admin/...
    m = location.hostname.match(/^([^.]+)\.myshopify\.com$/);
    if (m) return m[1];
    return null;
  }

  function onDraftOrderPage() {
    return CONFIG.pathTest.test(location.pathname);
  }

  // ---- line-item detection (shadow-piercing, selector-agnostic) ------------
  function findLineRows() {
    const hrefEls = deepQueryAll(el => {
      const h = el.getAttribute && el.getAttribute('href');
      return h && /\/products\/\d+/.test(h);
    });

    // Group by variant id (falls back to product id). The admin renders both an
    // <s-internal-link> and a paired empty <a> for the same href — grouping and
    // keeping the element with the most text de-dupes them and gives us the title.
    const groups = new Map();
    hrefEls.forEach(el => {
      const href = el.getAttribute('href') || '';
      const vm = href.match(/\/variants\/(\d+)/);
      const pm = href.match(/\/products\/(\d+)/);
      const gid = vm ? 'v' + vm[1] : (pm ? 'p' + pm[1] : href);
      const prev = groups.get(gid);
      const txt = (el.textContent || '').trim();
      if (!prev || txt.length > (prev.el.textContent || '').trim().length) {
        groups.set(gid, { el, productId: pm ? pm[1] : null, variantId: vm ? vm[1] : null });
      }
    });

    const out = [];
    const usedRows = new Set();
    groups.forEach(g => {
      const title = (g.el.textContent || '').trim();
      if (!title || title.length < 2) return;
      // The "row" = nearest ancestor whose text contains a currency amount.
      let el = g.el, row = null, hops = 0;
      while (el && hops < 12) {
        const p = parentAcrossShadow(el);
        if (!p) break;
        if (PRICE_RE.test(p.textContent || '')) { row = p; break; }
        el = p; hops++;
      }
      // Badge host = the block that holds the title/SKU but not yet a price
      // (so the badge sits under the SKU, not in the price column).
      let host = g.el, h2 = 0;
      while (host && h2 < 8) {
        const p = parentAcrossShadow(host);
        if (!p || PRICE_RE.test(p.textContent || '')) break;
        host = p; h2++;
      }
      row = row || host;
      if (!row || usedRows.has(row)) return;
      usedRows.add(row);
      out.push({ row, badgeHost: host || row, anchor: g.el, productId: g.productId, variantId: g.variantId, title });
    });
    return out;
  }

  function extractRow(info) {
    const text = (info.row.textContent || '').replace(/\s+/g, ' ').trim();
    let sku = '';
    const skuM = text.match(/SKU\s*([A-Za-z0-9._\/\-]+)/i);
    if (skuM) {
      sku = skuM[1];
      // The admin prints the SKU twice back-to-back ("FF-T10FF-T10") — halve it.
      const half = sku.length / 2;
      if (sku.length % 2 === 0 && sku.slice(0, half) === sku.slice(half)) sku = sku.slice(0, half);
    }
    const priceM = text.match(/\$\s?([\d,]+(?:\.\d{2})?)/);
    let priceCents = null;
    if (priceM) priceCents = Math.round(parseFloat(priceM[1].replace(/,/g, '')) * 100);
    return {
      title: info.title,
      sku,
      variantTitle: '',
      priceCents,
      productId: info.productId,
      variantId: info.variantId
    };
  }

  // ---- badge rendering (inline-styled; can't rely on content.css in shadow) -
  const BADGE_BASE = 'display:inline-block;margin-top:4px;padding:2px 8px;border-radius:10px;' +
    'font:600 11px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;' +
    'letter-spacing:.2px;white-space:nowrap;vertical-align:middle;';
  const BADGE_STYLE = {
    pending: 'background:#f1f2f4;color:#6b7177;',
    sale:    'background:#e7f6ec;color:#0a7d32;border:1px solid #b6e3c4;',
    full:    'background:#f1f2f4;color:#6b7177;',
    unknown: 'background:#fff4e5;color:#8a5a00;border:1px solid #ffd8a8;'
  };

  function badgeFor(info) {
    const host = info.badgeHost || info.row;
    let b = host.querySelector(':scope > .afsrrp-badge');
    if (!b) {
      b = document.createElement('span');
      b.className = 'afsrrp-badge';
      host.appendChild(b);
    }
    return b;
  }
  function setBadge(info, state, html, tip) {
    const b = badgeFor(info);
    b.style.cssText = BADGE_BASE + (BADGE_STYLE[state] || '');
    b.innerHTML = html;
    if (tip) b.title = tip; else b.removeAttribute('title');
    return b;
  }

  function renderPending(info) {
    setBadge(info, 'pending', 'checking price…');
  }

  function renderResult(info, res) {
    if (!res || !res.ok) {
      setBadge(info, 'unknown', 'no live price',
        (res && res.reason) ? res.reason : 'Could not match this line to a storefront product');
      return { unknown: true };
    }
    if (res.onSale) {
      const p = pct(res.rrp, res.promo);
      setBadge(info, 'sale',
        '<strong>ON SALE</strong> &nbsp;was ' + money(res.rrp, res.currency || currency) +
        ' &middot; save ' + money(res.saving, res.currency || currency) + (p != null ? ' (' + p + '%)' : ''),
        'Matched by ' + res.matchedBy + ' → ' + (res.productTitle || '') +
        (res.variantTitle && res.variantTitle !== 'Default Title' ? ' / ' + res.variantTitle : ''));
      return { onSale: true, rrp: res.rrp, promo: res.promo, saving: res.saving };
    }
    setBadge(info, 'full', 'not on sale',
      'RRP = current price (' + money(res.promo, res.currency || currency) + '), matched by ' + res.matchedBy);
    return { onSale: false, rrp: res.rrp != null ? res.rrp : res.promo, promo: res.promo, saving: 0 };
  }

  // ---- summary panel (light DOM — content.css applies) ---------------------
  function ensureSummary() {
    if (summaryEl && document.body.contains(summaryEl)) return summaryEl;
    summaryEl = document.createElement('div');
    summaryEl.className = 'afsrrp-summary';
    summaryEl.innerHTML =
      '<div class="afsrrp-head">' +
        '<span class="afsrrp-dot"></span><span class="afsrrp-title">RRP Radar</span>' +
        '<button class="afsrrp-btn afsrrp-rescan" title="Re-scan the line items">Rescan</button>' +
        '<button class="afsrrp-btn afsrrp-hide" title="Hide">&times;</button>' +
      '</div>' +
      '<div class="afsrrp-body"><div class="afsrrp-empty">Scanning line items…</div></div>';
    document.body.appendChild(summaryEl);
    summaryEl.querySelector('.afsrrp-rescan').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'clearCache' }, () => scan(true));
    });
    summaryEl.querySelector('.afsrrp-hide').addEventListener('click', () => {
      summaryEl.classList.add('afsrrp-collapsed');
    });
    summaryEl.querySelector('.afsrrp-head').addEventListener('click', (e) => {
      if (e.target.closest('.afsrrp-btn')) return;
      summaryEl.classList.toggle('afsrrp-collapsed');
    });
    return summaryEl;
  }

  function removeSummary() {
    if (summaryEl) { summaryEl.remove(); summaryEl = null; }
  }

  function renderSummary(stats) {
    const el = ensureSummary();
    const body = el.querySelector('.afsrrp-body');
    if (!stats.lines) {
      const msg = stats.noStore
        ? 'This store isn\'t mapped to a storefront yet. Open the extension Options to add it.'
        : 'No line items detected yet. Add a product, then Rescan.';
      body.innerHTML = '<div class="afsrrp-empty">' + msg + '</div>';
      return;
    }
    const rows = [
      ['Lines scanned', String(stats.lines)],
      ['On sale', String(stats.onSale)],
      ['Total RRP', money(stats.totalRRP, currency)],
      ['Total now', money(stats.totalPromo, currency)]
    ];
    let html = rows.map(r => '<div class="afsrrp-row"><span>' + r[0] + '</span><span>' + r[1] + '</span></div>').join('');
    html += '<div class="afsrrp-row afsrrp-saving"><span>Customer saves</span><span>' +
      money(stats.totalSaving, currency) + '</span></div>';
    if (stats.unknown) html += '<div class="afsrrp-note">' + stats.unknown + ' line(s) had no live price match</div>';
    body.innerHTML = html;
  }

  // ---- main scan -----------------------------------------------------------
  function scan(force) {
    if (!enabled || !onDraftOrderPage()) { removeSummary(); return; }
    const store = currentStore();
    const infos = findLineRows();
    log('scan: store=', store, 'rows=', infos.length, location.pathname);
    ensureSummary();

    if (!infos.length) { renderSummary({ lines: 0 }); return; }
    if (!store) { renderSummary({ lines: 0, noStore: true }); return; }

    const stats = { lines: 0, onSale: 0, totalRRP: 0, totalPromo: 0, totalSaving: 0, unknown: 0 };
    const acc = (r) => {
      if (!r) return;
      stats.lines += 1;
      if (r.unknown) { stats.unknown += 1; return; }
      if (r.onSale) stats.onSale += 1;
      stats.totalRRP += (r.rrp || r.promo || 0);
      stats.totalPromo += (r.promo || 0);
      stats.totalSaving += (r.saving || 0);
    };

    let pending = 0, dispatched = false;
    const finish = () => { if (dispatched && pending <= 0) renderSummary(stats); };

    infos.forEach(info => {
      const details = extractRow(info);
      const key = (details.variantId || details.sku || details.title) + '|' + (details.priceCents || '');
      const cached = info.row.__afsrrp;
      if (!force && cached && cached.key === key && cached.r) {
        acc(cached.r); // reuse — no re-request, no badge flicker
        return;
      }
      pending += 1;
      renderPending(info);
      chrome.runtime.sendMessage(
        { type: 'resolvePricing', payload: Object.assign({ store }, details) },
        (res) => {
          const r = renderResult(info, res);
          try { info.row.__afsrrp = { key, r }; } catch (e) { /* row may be gone */ }
          acc(r);
          pending -= 1;
          finish();
        }
      );
    });
    dispatched = true;
    finish();
  }

  function scheduleScan() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => scan(false), CONFIG.rescanDebounceMs);
  }

  // ---- observers: SPA route changes + DOM mutations + poll ------------------
  function watch() {
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => scheduleScan());
    observer.observe(document.body, { childList: true, subtree: true });

    // Shadow-DOM mutations don't reach the document observer, so poll as a net.
    clearInterval(pollTimer);
    pollTimer = setInterval(() => { if (enabled && onDraftOrderPage()) scan(false); }, CONFIG.pollMs);

    // patch history so SPA navigations re-trigger a scan
    ['pushState', 'replaceState'].forEach(fn => {
      const orig = history[fn];
      history[fn] = function () { const r = orig.apply(this, arguments); window.dispatchEvent(new Event('afsrrp:navigate')); return r; };
    });
    window.addEventListener('popstate', () => window.dispatchEvent(new Event('afsrrp:navigate')));
    window.addEventListener('afsrrp:navigate', () => setTimeout(() => scan(true), 400));
  }

  // ---- init ----------------------------------------------------------------
  function init() {
    chrome.storage.sync.get(['enabled', 'currency'], (s) => {
      enabled = s.enabled !== false; // default on
      currency = s.currency || 'AUD';
      log('init enabled=', enabled, 'currency=', currency);
      watch();
      setTimeout(() => scan(true), 600);
    });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.enabled) { enabled = changes.enabled.newValue !== false; scan(true); }
      if (changes.currency) currency = changes.currency.newValue || 'AUD';
    });
    // popup can ask us to rescan
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'rescan') { chrome.runtime.sendMessage({ type: 'clearCache' }, () => scan(true)); }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
