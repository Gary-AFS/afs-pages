// AFS RRP Radar — MV3 service worker.
// Resolves RRP (compare-at) vs promo pricing for a draft-order line, tokenless,
// via the storefront predictive-search + product AJAX (/products/{handle}.js) endpoints.
// Runs in the extension context so cross-origin fetches to the storefront bypass
// page CORS (the content script cannot fetch the storefront directly from admin.shopify.com).

// Store handle (as it appears in admin.shopify.com/store/{handle}) -> storefront origin.
const DEFAULT_STOREFRONTS = {
  'gymandfitness-au': 'https://www.gymandfitness.com.au', // canonical host (apex 301s to www)
  'revel-saunas': 'https://revelsaunas.com.au'
};

const cache = new Map(); // cacheKey -> resolved pricing object

async function getConfig() {
  const stored = await chrome.storage.sync.get(['storefronts', 'currency']);
  return {
    storefronts: Object.assign({}, DEFAULT_STOREFRONTS, stored.storefronts || {}),
    currency: stored.currency || 'AUD'
  };
}

function storefrontFor(store, cfg) {
  const d = cfg.storefronts[store];
  return d ? String(d).replace(/\/+$/, '') : null;
}

async function fetchJSON(url) {
  const r = await fetch(url, { credentials: 'omit', headers: { 'Accept': 'application/json' } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

function pickProduct(products, title, sku) {
  if (!products || !products.length) return null;
  const t = (title || '').trim().toLowerCase();
  if (sku) {
    const s = sku.toLowerCase();
    const bySku = products.find(p => (p.variants || []).some(v => (v.sku || '').toLowerCase() === s));
    if (bySku) return bySku;
  }
  let m = products.find(p => (p.title || '').trim().toLowerCase() === t);
  if (m) return m;
  m = products.find(p => t && (p.title || '').trim().toLowerCase().indexOf(t) === 0);
  if (m) return m;
  m = products.find(p => t && (p.title || '').trim().toLowerCase().indexOf(t) !== -1);
  return m || products[0];
}

function pickVariant(variants, sku, variantTitle, priceCents, variantId) {
  if (!variants || !variants.length) return null;
  // Exact: the admin line's variant id is the same global id the storefront returns.
  if (variantId) {
    const v = variants.find(x => String(x.id) === String(variantId));
    if (v) return { v: v, by: 'variant id' };
  }
  if (sku) {
    const s = sku.toLowerCase();
    const v = variants.find(x => (x.sku || '').toLowerCase() === s);
    if (v) return { v: v, by: 'SKU' };
  }
  if (variantTitle) {
    const vt = variantTitle.trim().toLowerCase();
    const v = variants.find(x => (x.title || '').trim().toLowerCase() === vt);
    if (v) return { v: v, by: 'variant' };
  }
  if (priceCents != null) {
    const v = variants.find(x => Number(x.price) === Number(priceCents));
    if (v) return { v: v, by: 'price' };
  }
  return { v: variants[0], by: variants.length === 1 ? 'only variant' : 'first variant' };
}

async function resolveStorefront(domain, payload) {
  const title = payload.title || '';
  const q = encodeURIComponent(title);
  const suggestUrl = domain + '/search/suggest.json?q=' + q +
    '&resources[type]=product&resources[limit]=6' +
    '&resources[options][fields]=title,variants.sku,variants.title';
  const s = await fetchJSON(suggestUrl);
  const products = (((s.resources || {}).results || {}).products) || [];
  const prod = pickProduct(products, title, payload.sku);
  if (!prod || !prod.handle) return { ok: false, reason: 'no product match on storefront' };

  const pj = await fetchJSON(domain + '/products/' + prod.handle + '.js');
  const pick = pickVariant(pj.variants || [], payload.sku, payload.variantTitle, payload.priceCents, payload.variantId);
  if (!pick || !pick.v) return { ok: false, reason: 'no variant match', handle: prod.handle };

  const v = pick.v;
  const rrp = v.compare_at_price != null ? Number(v.compare_at_price) : null;
  const promo = Number(v.price);
  const onSale = rrp != null && rrp > promo;
  return {
    ok: true,
    handle: prod.handle,
    productTitle: pj.title,
    variantTitle: v.title,
    sku: v.sku || '',
    rrp: rrp,
    promo: promo,
    onSale: onSale,
    saving: onSale ? (rrp - promo) : 0,
    matchedBy: pick.by,
    productUrl: domain + '/products/' + prod.handle
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'resolvePricing') {
    (async () => {
      try {
        const cfg = await getConfig();
        const store = msg.payload.store;
        const domain = storefrontFor(store, cfg);
        if (!domain) {
          sendResponse({ ok: false, reason: 'No storefront set for store "' + store + '". Open the extension Options and map it.' });
          return;
        }
        const key = domain + '|' + (msg.payload.variantId || '') + '|' + (msg.payload.sku || '') + '|' + (msg.payload.title || '') + '|' + (msg.payload.priceCents || '');
        if (cache.has(key)) { sendResponse(Object.assign({ cached: true }, cache.get(key))); return; }
        const res = await resolveStorefront(domain, msg.payload);
        res.currency = cfg.currency;
        cache.set(key, res);
        sendResponse(res);
      } catch (e) {
        sendResponse({ ok: false, reason: String((e && e.message) || e) });
      }
    })();
    return true; // keep the message channel open for the async response
  }

  if (msg.type === 'clearCache') {
    cache.clear();
    sendResponse({ ok: true });
  }
});
