// AFS RRP Radar — popup: enable toggle, rescan, open options.
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(['enabled'], (s) => {
  $('enabled').checked = s.enabled !== false;
});

$('enabled').addEventListener('change', (e) => {
  chrome.storage.sync.set({ enabled: e.target.checked }, () => {
    setStatus(e.target.checked ? 'Enabled' : 'Disabled');
  });
});

$('rescan').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'rescan' }, () => {
      if (chrome.runtime.lastError) {
        setStatus('Open a Shopify draft order first');
      } else {
        setStatus('Rescanning…');
      }
    });
  });
});

$('options').addEventListener('click', () => chrome.runtime.openOptionsPage());

function setStatus(t) {
  $('status').textContent = t;
  setTimeout(() => { if ($('status').textContent === t) $('status').textContent = ''; }, 2500);
}
