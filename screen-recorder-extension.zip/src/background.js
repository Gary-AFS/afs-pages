import { transition, STATES } from './lib/state.js';

let appState = STATES.IDLE;
let bubblePosition = { nx: 0.12, ny: 0.82 };
let recordingStartTs = 0;
let lastWithCamera = true;

// Messages addressed to the offscreen document reach all extension contexts;
// this background listener early-returns on them (see below) while the offscreen
// doc filters on msg.target === 'offscreen'. That prevents a relay loop.
function toOffscreen(msg) {
  return chrome.runtime.sendMessage(msg).catch(() => {});
}

async function ensureOffscreen() {
  const has = await chrome.offscreen.hasDocument();
  if (!has) {
    await chrome.offscreen.createDocument({
      url: 'src/offscreen.html',
      reasons: ['USER_MEDIA', 'DISPLAY_MEDIA'],
      justification: 'Record screen and camera into a video file.'
    });
  }
}

async function injectControls(tabId) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['src/content.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['src/content.js'] });
    await chrome.tabs.sendMessage(tabId, {
      type: 'SHOW_CONTROLS', bubblePosition, startTs: recordingStartTs, withCamera: lastWithCamera
    });
  } catch (e) {
    // Some pages (chrome://, Web Store, PDF viewer) block injection. Recording continues regardless.
    console.warn('controls not injectable on this tab', e);
  }
}

async function startRecording({ withCamera, withMic }) {
  // In an MV3 service worker, chooseDesktopMedia requires a target tab to anchor
  // the picker; without it the call errors and returns no stream id.
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) throw new Error('no active tab to anchor the screen picker');
  const streamId = await new Promise((resolve, reject) => {
    chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], tab, (id) => {
      if (!id) reject(new Error('cancelled')); else resolve(id);
    });
  });
  await ensureOffscreen();
  lastWithCamera = withCamera;
  recordingStartTs = Date.now(); // baseline; refined when RECORDING_STARTED arrives
  await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_START', streamId, withCamera, withMic, bubblePosition });
  appState = transition(appState, 'START');
}

async function finishRecording() {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) {
    appState = transition(appState, 'STOP'); // -> preview
  }
  if (appState === STATES.PREVIEW) {
    appState = transition(appState, 'RESET'); // -> idle, ready for the next recording
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) chrome.tabs.sendMessage(tab.id, { type: 'HIDE_CONTROLS' }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === 'offscreen') return false; // destined for the offscreen doc, not background
  (async () => {
    try {
      if (msg.type === 'START_RECORDING') {
        await startRecording(msg);
      } else if (msg.type === 'STOP_RECORDING') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_STOP' });
      } else if (msg.type === 'PAUSE') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_PAUSE' });
      } else if (msg.type === 'RESUME') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_RESUME' });
      } else if (msg.type === 'BUBBLE_MOVED') {
        bubblePosition = msg.bubblePosition;
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_BUBBLE', bubblePosition });
      } else if (msg.type === 'RECORDING_STARTED') {
        recordingStartTs = Date.now();
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) await injectControls(tab.id);
      } else if (msg.type === 'RECORDING_FAILED') {
        appState = transition(appState, 'FAIL');
      } else if (msg.type === 'RECORDING_DONE') {
        await chrome.storage.local.set({ lastRecording: { url: msg.url, filename: msg.filename } });
        await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
        await finishRecording();
      }
    } catch (e) {
      appState = transition(appState, 'FAIL');
      console.warn('background error', e);
    }
    sendResponse({ ok: true });
  })();
  return true; // async sendResponse
});

// Follow across tabs: re-inject controls into the newly active/updated tab while recording.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) await injectControls(tabId);
});
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status === 'complete' && tab.active &&
      (appState === STATES.RECORDING || appState === STATES.PAUSED)) {
    await injectControls(tabId);
  }
});
