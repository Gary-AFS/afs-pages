import { transition, STATES } from './lib/state.js';

let appState = STATES.IDLE;
let bubblePosition = { nx: 0.12, ny: 0.82 };
let recordingStartTs = 0;
let lastWithCamera = true;
let recorderWindowId = null;

// Messages addressed to the recorder window reach all extension contexts; this
// background listener early-returns on them while the recorder window filters on
// msg.target === 'recorder'. That prevents a relay loop.
function toRecorder(msg) {
  return chrome.runtime.sendMessage(msg).catch(() => {});
}

// Find a real browser tab to inject the on-page controls into. A bare
// {active, currentWindow} query can return empty when the recorder/DevTools
// window is focused, so fall through progressively wider lookups.
async function getActiveTab() {
  for (const q of [
    { active: true, lastFocusedWindow: true },
    { active: true, currentWindow: true },
    { active: true }
  ]) {
    const tabs = await chrome.tabs.query(q);
    const t = tabs.find((x) => x && x.id != null && x.id >= 0 && x.windowId !== recorderWindowId);
    if (t) return t;
  }
  const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['normal'] });
  for (const w of wins) {
    if (w.id === recorderWindowId) continue;
    const t = (w.tabs || []).find((x) => x.active) || (w.tabs || [])[0];
    if (t) return t;
  }
  return null;
}

async function injectControls(tabId) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['src/content.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['src/content.js'] });
    await chrome.tabs.sendMessage(tabId, {
      type: 'SHOW_CONTROLS', bubblePosition, startTs: recordingStartTs, withCamera: lastWithCamera
    });
  } catch (e) {
    // Some pages (chrome://, Web Store, PDF viewer) block injection. Recording continues regardless.
    console.warn('controls not injectable on this tab', e);
  }
}

async function closeRecorderWindow() {
  if (recorderWindowId != null) {
    const id = recorderWindowId;
    recorderWindowId = null;
    try { await chrome.windows.remove(id); } catch (e) { /* already gone */ }
  }
}

async function startRecording({ withCamera, withMic }) {
  lastWithCamera = withCamera;
  await chrome.storage.local.set({ recParams: { withCamera, withMic, bubblePosition } });
  // A small visible window hosts the picker + recorder (the only context that can
  // call desktopCapture without tab-anchoring and survive tab switches).
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('src/recorder.html'),
    type: 'popup', width: 420, height: 170, focused: true
  });
  recorderWindowId = win.id;
  appState = transition(appState, 'START');
}

async function finishRecording() {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) {
    appState = transition(appState, 'STOP'); // -> preview
  }
  if (appState === STATES.PREVIEW) {
    appState = transition(appState, 'RESET'); // -> idle, ready for the next recording
  }
  const tab = await getActiveTab();
  if (tab) chrome.tabs.sendMessage(tab.id, { type: 'HIDE_CONTROLS' }).catch(() => {});
  await closeRecorderWindow();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === 'recorder') return false; // destined for the recorder window, not background
  (async () => {
    try {
      if (msg.type === 'START_RECORDING') {
        await startRecording(msg);
      } else if (msg.type === 'STOP_RECORDING') {
        await toRecorder({ target: 'recorder', type: 'RECORDER_STOP' });
      } else if (msg.type === 'PAUSE') {
        await toRecorder({ target: 'recorder', type: 'RECORDER_PAUSE' });
      } else if (msg.type === 'RESUME') {
        await toRecorder({ target: 'recorder', type: 'RECORDER_RESUME' });
      } else if (msg.type === 'BUBBLE_MOVED') {
        bubblePosition = msg.bubblePosition;
        await toRecorder({ target: 'recorder', type: 'RECORDER_BUBBLE', bubblePosition });
      } else if (msg.type === 'RECORDING_STARTED') {
        recordingStartTs = Date.now();
        const tab = await getActiveTab();
        if (tab) await injectControls(tab.id);
      } else if (msg.type === 'RECORDING_CANCELLED') {
        if (appState !== STATES.IDLE) appState = transition(appState, 'FAIL');
        await closeRecorderWindow();
      } else if (msg.type === 'RECORDING_FAILED') {
        appState = transition(appState, 'FAIL');
        await chrome.storage.local.set({ lastError: msg.error || 'unknown error' });
        await closeRecorderWindow();
        await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
      } else if (msg.type === 'RECORDING_DONE') {
        await finishRecording();
        await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
      }
    } catch (e) {
      appState = transition(appState, 'FAIL');
      console.warn('background error', e);
    }
    sendResponse({ ok: true });
  })();
  return true; // async sendResponse
});

// If the user closes the recorder window mid-recording, treat it as a stop/abort.
chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId !== recorderWindowId) return;
  recorderWindowId = null;
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) {
    appState = transition(appState, 'FAIL');
    getActiveTab().then((tab) => {
      if (tab) chrome.tabs.sendMessage(tab.id, { type: 'HIDE_CONTROLS' }).catch(() => {});
    });
  }
});

// Follow across tabs: re-inject controls into the newly active/updated tab while recording.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) await injectControls(tabId);
});
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status === 'complete' && tab.active &&
      (appState === STATES.RECORDING || appState === STATES.PAUSED)) {
    await injectControls(tabId);
  }
});
