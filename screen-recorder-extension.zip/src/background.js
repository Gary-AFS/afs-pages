import { transition, STATES } from './lib/state.js';

let appState = STATES.IDLE;
let bubblePosition = { nx: 0.12, ny: 0.82 };
let recordingStartTs = 0;
let lastWithCamera = true;

// Messages addressed to the offscreen document reach all extension contexts;
// this background listener early-returns on them (see below) while the offscreen
// doc filters on msg.target === 'offscreen'. That prevents a relay loop.
function toOffscreen(msg) {
  return chrome.runtime.sendMessage(msg).catch(() => {});
}

// Find a real browser tab to anchor the screen picker / inject controls into.
// A bare {active, currentWindow} query can return empty when a popped-out
// DevTools window is focused, so fall through progressively wider lookups.
async function getActiveTab() {
  for (const q of [
    { active: true, lastFocusedWindow: true },
    { active: true, currentWindow: true },
    { active: true }
  ]) {
    const tabs = await chrome.tabs.query(q);
    const t = tabs.find((x) => x && x.id != null && x.id >= 0);
    if (t) return t;
  }
  const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['normal'] });
  for (const w of wins) {
    const t = (w.tabs || []).find((x) => x.active) || (w.tabs || [])[0];
    if (t) return t;
  }
  return null;
}

async function ensureOffscreen() {
  const has = await chrome.offscreen.hasDocument();
  if (!has) {
    await chrome.offscreen.createDocument({
      url: 'src/offscreen.html',
      reasons: ['USER_MEDIA', 'DISPLAY_MEDIA'],
      justification: 'Record screen and camera into a video file.'
    });
  }
}

async function injectControls(tabId) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['src/content.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['src/content.js'] });
    await chrome.tabs.sendMessage(tabId, {
      type: 'SHOW_CONTROLS', bubblePosition, startTs: recordingStartTs, withCamera: lastWithCamera
    });
  } catch (e) {
    // Some pages (chrome://, Web Store, PDF viewer) block injection. Recording continues regardless.
    console.warn('controls not injectable on this tab', e);
  }
}

async function startRecording({ withCamera, withMic }) {
  // The offscreen document opens the screen picker AND consumes the stream id,
  // so the id is created and used in one context (avoids "AbortError: Invalid state"
  // that occurs when a service-worker, tab-anchored id is consumed in offscreen).
  await ensureOffscreen();
  lastWithCamera = withCamera;
  recordingStartTs = Date.now(); // baseline; refined when RECORDING_STARTED arrives
  await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_START', withCamera, withMic, bubblePosition });
  appState = transition(appState, 'START');
}

async function finishRecording() {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) {
    appState = transition(appState, 'STOP'); // -> preview
  }
  if (appState === STATES.PREVIEW) {
    appState = transition(appState, 'RESET'); // -> idle, ready for the next recording
  }
  const tab = await getActiveTab();
  if (tab) chrome.tabs.sendMessage(tab.id, { type: 'HIDE_CONTROLS' }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === 'offscreen') return false; // destined for the offscreen doc, not background
  (async () => {
    try {
      if (msg.type === 'START_RECORDING') {
        await startRecording(msg);
      } else if (msg.type === 'STOP_RECORDING') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_STOP' });
      } else if (msg.type === 'PAUSE') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_PAUSE' });
      } else if (msg.type === 'RESUME') {
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_RESUME' });
      } else if (msg.type === 'BUBBLE_MOVED') {
        bubblePosition = msg.bubblePosition;
        await toOffscreen({ target: 'offscreen', type: 'OFFSCREEN_BUBBLE', bubblePosition });
      } else if (msg.type === 'RECORDING_STARTED') {
        recordingStartTs = Date.now();
        const tab = await getActiveTab();
        if (tab) await injectControls(tab.id);
      } else if (msg.type === 'RECORDING_CANCELLED') {
        // User dismissed the screen picker; quietly return to idle.
        if (appState !== STATES.IDLE) appState = transition(appState, 'FAIL');
      } else if (msg.type === 'RECORDING_FAILED') {
        appState = transition(appState, 'FAIL');
        await chrome.storage.local.set({ lastError: msg.error || 'unknown error' });
        await chrome.storage.local.remove('lastRecording');
        await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
      } else if (msg.type === 'RECORDING_DONE') {
        await chrome.storage.local.set({ lastRecording: { url: msg.url, filename: msg.filename } });
        await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
        await finishRecording();
      }
    } catch (e) {
      appState = transition(appState, 'FAIL');
      console.warn('background error', e);
    }
    sendResponse({ ok: true });
  })();
  return true; // async sendResponse
});

// Follow across tabs: re-inject controls into the newly active/updated tab while recording.
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (appState === STATES.RECORDING || appState === STATES.PAUSED) await injectControls(tabId);
});
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status === 'complete' && tab.active &&
      (appState === STATES.RECORDING || appState === STATES.PAUSED)) {
    await injectControls(tabId);
  }
});
