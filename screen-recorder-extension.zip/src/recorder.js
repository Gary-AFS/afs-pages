import { pickMimeType, MIME_CANDIDATES } from './lib/mime.js';
import { makeFilename } from './lib/filename.js';
import { putRecording, clearRecording } from './lib/recordingstore.js';

// Slim controls toolbar. Records the chosen screen surface DIRECTLY (plus mic).
// The webcam head is a separate on-page element (content script). Pause/Stop can
// come from this toolbar OR the extension icon popup, relayed via a storage command.

const statusEl = document.getElementById('status');
const timeEl = document.getElementById('time');
const pauseBtn = document.getElementById('pause');
const stopBtn = document.getElementById('stop');

let recorder = null;
let chunks = [];
let stream = null;
let timerId = null;
let startedAt = 0;
let paused = false;
let lastCmd = 0;

function fmt(secs) {
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function startTimer() {
  timerId = setInterval(() => {
    if (!paused) timeEl.textContent = fmt(Math.floor((Date.now() - startedAt) / 1000));
  }, 500);
}

function stopTracks() {
  if (stream) stream.getTracks().forEach((t) => t.stop());
  stream = null;
}

// The window opens maximised so Chrome's "choose what to record" picker is big and
// easy to use (team feedback). Once a surface is chosen we collapse to the slim
// always-there toolbar in the top-right corner.
async function shrinkToToolbar() {
  document.body.classList.add('live');
  try {
    const win = await chrome.windows.getCurrent();
    const W = 360, H = 110;
    await chrome.windows.update(win.id, { state: 'normal' });
    await chrome.windows.update(win.id, {
      width: W, height: H,
      left: Math.max(0, (window.screen.availWidth || 1280) - W - 16),
      top: 16
    });
  } catch (e) { /* non-fatal: window stays as-is */ }
}

// Counts down before recording starts. As well as the small recorder-window text,
// it writes a `countdown` storage flag the content script reads to paint a big,
// obvious overlay on the page being recorded. Cleared (0) before recorder.start(),
// so the countdown never lands in the actual recording.
async function runCountdown(n) {
  for (let c = n; c >= 1; c -= 1) {
    statusEl.textContent = `Starting in ${c}...`;
    await chrome.storage.local.set({ countdown: c });
    await new Promise((r) => setTimeout(r, 700));
  }
  await chrome.storage.local.set({ countdown: 0 });
}

async function setRecording(on) {
  await chrome.storage.local.set({ recording: on });
}

async function openResult() {
  await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
  window.close();
}

async function fail(error) {
  stopTracks();
  recorder = null;
  await setRecording(false);
  try { await clearRecording(); } catch (e) { /* ignore */ }
  await chrome.storage.local.set({ lastError: error });
  await openResult();
}

function doPause() {
  if (recorder && recorder.state === 'recording') {
    recorder.pause();
    paused = true;
    pauseBtn.textContent = 'Resume';
    chrome.storage.local.set({ paused: true });
  }
}
function doResume() {
  if (recorder && recorder.state === 'paused') {
    recorder.resume();
    paused = false;
    pauseBtn.textContent = 'Pause';
    chrome.storage.local.set({ paused: false });
  }
}
function stop() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
}

async function start({ withCamera, withMic, cameraLabel, micId }) {
  let step = 'screen picker';
  try {
    await chrome.storage.local.set({ headOn: withCamera !== false, headCamLabel: cameraLabel || '' });

    statusEl.textContent = 'Choose what to record...';
    const streamId = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (id) => resolve(id));
    });
    if (!streamId) { window.close(); return; } // user dismissed the picker

    await shrinkToToolbar(); // surface chosen: collapse the big setup window to the toolbar

    step = 'screen capture';
    const screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }
    });
    const tracks = [...screenStream.getVideoTracks()];

    if (withMic) {
      let micStream = null;
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: micId ? { deviceId: { exact: micId } } : true,
          video: false
        });
      } catch (micErr) {
        // Chosen mic unavailable: fall back to the default mic rather than going silent.
        try { micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false }); }
        catch (e2) { console.warn('mic unavailable:', e2 && e2.name); }
      }
      if (micStream && micStream.getAudioTracks().length) tracks.push(micStream.getAudioTracks()[0]);
    }

    stream = new MediaStream(tracks);
    screenStream.getVideoTracks()[0].onended = () => stop(); // native "stop sharing" bar

    step = 'recorder setup';
    const mimeType = pickMimeType(MIME_CANDIDATES, (m) => MediaRecorder.isTypeSupported(m));
    recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = onStop;

    await setRecording(true); // shows the on-page head; user can position it during the countdown
    await runCountdown(3);
    recorder.start(100);
    startedAt = Date.now();
    paused = false;
    await chrome.storage.local.set({ startedAt, paused: false });
    startTimer();
    statusEl.textContent = 'Recording. Drag your head where you want it on the page.';
  } catch (e) {
    await fail(`${step}: ${(e && e.name) || 'Error'}: ${(e && e.message) || e}`);
  }
}

async function onStop() {
  if (timerId) clearInterval(timerId);
  const type = recorder.mimeType || 'video/webm';
  const blob = new Blob(chunks, { type });
  const filename = makeFilename(new Date());
  stopTracks();
  recorder = null;
  await setRecording(false);
  statusEl.textContent = 'Saving...';
  try {
    await putRecording(blob, filename);
    // Anonymous +1 to the team usage counter (no identity, no content, just a tally).
    fetch('https://afs-recorder-counter.josh-03c.workers.dev/hit', { method: 'POST', keepalive: true }).catch(() => {});
    await chrome.storage.local.remove('lastError');
    await openResult();
  } catch (e) {
    await fail(`save: ${(e && e.message) || e}`);
  }
}

pauseBtn.addEventListener('click', () => {
  if (recorder && recorder.state === 'paused') doResume();
  else doPause();
});
stopBtn.addEventListener('click', () => stop());

// Commands relayed from the extension icon popup.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.command) return;
  const cmd = changes.command.newValue;
  if (!cmd || cmd.n === lastCmd) return;
  lastCmd = cmd.n;
  if (cmd.action === 'pause') doPause();
  else if (cmd.action === 'resume') doResume();
  else if (cmd.action === 'stop') stop();
});

// Safety: clear the on-page heads if this toolbar is closed mid-recording.
window.addEventListener('beforeunload', () => { chrome.storage.local.set({ recording: false }); });

(async () => {
  const { recParams } = await chrome.storage.local.get('recParams');
  start(recParams || { withCamera: true, withMic: true });
})();
