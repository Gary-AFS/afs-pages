import { pickMimeType, MIME_CANDIDATES } from './lib/mime.js';
import { makeFilename } from './lib/filename.js';
import { putRecording, clearRecording } from './lib/recordingstore.js';

// Controls-only window. Records the chosen screen surface DIRECTLY (plus mic).
// The webcam head is a separate on-page element (content script) that the screen
// capture films in place, so there is no canvas compositing here.

const statusEl = document.getElementById('status');
const timeEl = document.getElementById('time');
const pauseBtn = document.getElementById('pause');
const stopBtn = document.getElementById('stop');
const countdownEl = document.getElementById('countdown');

let recorder = null;
let chunks = [];
let stream = null;
let timerId = null;
let startedAt = 0;
let paused = false;

function fmt(secs) {
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function startTimer() {
  timerId = setInterval(() => {
    if (!paused) timeEl.textContent = fmt(Math.floor((Date.now() - startedAt) / 1000));
  }, 500);
}

function stopTracks() {
  if (stream) stream.getTracks().forEach((t) => t.stop());
  stream = null;
}

function runCountdown(n) {
  return new Promise((resolve) => {
    countdownEl.style.display = 'block';
    countdownEl.textContent = String(n);
    let c = n;
    const iv = setInterval(() => {
      c -= 1;
      if (c < 1) { clearInterval(iv); countdownEl.style.display = 'none'; resolve(); }
      else countdownEl.textContent = String(c);
    }, 700);
  });
}

async function setRecording(on) {
  await chrome.storage.local.set({ recording: on });
}

async function openResult() {
  await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
  window.close();
}

async function fail(error) {
  stopTracks();
  recorder = null;
  await setRecording(false);
  try { await clearRecording(); } catch (e) { /* ignore */ }
  await chrome.storage.local.set({ lastError: error });
  await openResult();
}

async function start({ withCamera, withMic, cameraId, micId }) {
  let step = 'screen picker';
  try {
    // Tell the on-page head which camera to use and whether to show.
    await chrome.storage.local.set({ headOn: withCamera !== false, headCam: cameraId || '' });

    statusEl.textContent = 'Choose what to record...';
    const streamId = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (id) => resolve(id));
    });
    if (!streamId) { window.close(); return; } // user dismissed the picker

    step = 'screen capture';
    const screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }
    });
    const tracks = [...screenStream.getVideoTracks()];

    // Mic is non-fatal: record the screen even if the mic is unavailable.
    if (withMic) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({
          audio: micId ? { deviceId: { ideal: micId } } : true,
          video: false
        });
        if (micStream.getAudioTracks().length) tracks.push(micStream.getAudioTracks()[0]);
      } catch (micErr) {
        console.warn('mic unavailable:', micErr && micErr.name);
      }
    }

    stream = new MediaStream(tracks);
    screenStream.getVideoTracks()[0].onended = () => stop(); // native "stop sharing" bar

    step = 'recorder setup';
    const mimeType = pickMimeType(MIME_CANDIDATES, (m) => MediaRecorder.isTypeSupported(m));
    recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = onStop;

    // Show the on-page head now so the user can position it during the countdown.
    await setRecording(true);
    statusEl.textContent = 'Starting...';
    await runCountdown(3);
    recorder.start(100);
    startedAt = Date.now();
    startTimer();
    statusEl.textContent = 'Recording. Drag your head where you want it on the page.';
  } catch (e) {
    await fail(`${step}: ${(e && e.name) || 'Error'}: ${(e && e.message) || e}`);
  }
}

async function onStop() {
  if (timerId) clearInterval(timerId);
  const type = recorder.mimeType || 'video/webm';
  const blob = new Blob(chunks, { type });
  const filename = makeFilename(new Date());
  stopTracks();
  recorder = null;
  await setRecording(false);
  statusEl.textContent = 'Saving...';
  try {
    await putRecording(blob, filename);
    await chrome.storage.local.remove('lastError');
    await openResult();
  } catch (e) {
    await fail(`save: ${(e && e.message) || e}`);
  }
}

function stop() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
}

pauseBtn.addEventListener('click', () => {
  if (!recorder) return;
  if (recorder.state === 'recording') { recorder.pause(); paused = true; pauseBtn.textContent = 'Resume'; }
  else if (recorder.state === 'paused') { recorder.resume(); paused = false; pauseBtn.textContent = 'Pause'; }
});
stopBtn.addEventListener('click', () => stop());

// Safety: if this window is closed mid-recording, clear the on-page heads.
window.addEventListener('beforeunload', () => { chrome.storage.local.set({ recording: false }); });

(async () => {
  const { recParams } = await chrome.storage.local.get('recParams');
  start(recParams || { withCamera: true, withMic: true });
})();
