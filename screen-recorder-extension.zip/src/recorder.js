import { pickMimeType, MIME_CANDIDATES } from './lib/mime.js';
import { bubbleDrawBox } from './lib/composite.js';
import { makeFilename } from './lib/filename.js';
import { putRecording } from './lib/recordingstore.js';

// This page runs in a small visible window. Unlike a service worker or an
// offscreen document, a normal extension window CAN call chrome.desktopCapture
// without anchoring to a tab, and it survives main-window tab switches.

const screenVideo = document.getElementById('screen');
const camVideo = document.getElementById('cam');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const statusEl = document.getElementById('status');
const timeEl = document.getElementById('time');
const pauseBtn = document.getElementById('pause');
const stopBtn = document.getElementById('stop');

let recorder = null;
let chunks = [];
let rafId = null;
let bubble = { nx: 0.12, ny: 0.82 };
let withCamera = true;
let screenStream = null;
let camStream = null;
let timerId = null;
let startedAt = 0;
let paused = false;

const BUBBLE_DIAMETER = 180;

function drawLoop() {
  if (screenVideo.videoWidth) {
    if (canvas.width !== screenVideo.videoWidth) {
      canvas.width = screenVideo.videoWidth;
      canvas.height = screenVideo.videoHeight;
    }
    ctx.drawImage(screenVideo, 0, 0, canvas.width, canvas.height);
    if (withCamera && camVideo.videoWidth) {
      const box = bubbleDrawBox({
        canvasW: canvas.width, canvasH: canvas.height,
        nx: bubble.nx, ny: bubble.ny, diameter: BUBBLE_DIAMETER
      });
      ctx.save();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.clip();
      const vw = camVideo.videoWidth, vh = camVideo.videoHeight;
      const scale = Math.max(box.size / vw, box.size / vh);
      const dw = vw * scale, dh = vh * scale;
      ctx.drawImage(camVideo, box.cx - dw / 2, box.cy - dh / 2, dw, dh);
      ctx.restore();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.stroke();
    }
  }
  rafId = requestAnimationFrame(drawLoop);
}

function fmt(secs) {
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function startTimer() {
  timerId = setInterval(() => {
    if (!paused) timeEl.textContent = fmt(Math.floor((Date.now() - startedAt) / 1000));
  }, 500);
}

function cleanupStreams() {
  cancelAnimationFrame(rafId);
  if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
  if (camStream) camStream.getTracks().forEach((t) => t.stop());
  screenStream = null;
  camStream = null;
}

async function start({ withCamera: wc, withMic, bubblePosition }) {
  let step = 'screen picker';
  try {
    withCamera = wc;
    if (bubblePosition) bubble = bubblePosition;

    statusEl.textContent = 'Choose what to record...';
    const streamId = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (id) => resolve(id));
    });
    if (!streamId) { // user dismissed the picker
      chrome.runtime.sendMessage({ type: 'RECORDING_CANCELLED' });
      return;
    }

    step = 'screen capture';
    screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }
    });
    screenVideo.srcObject = screenStream;

    // Camera/mic are non-fatal: if the webcam/mic is unavailable we still record the screen.
    if (wc || withMic) {
      try {
        camStream = await navigator.mediaDevices.getUserMedia({ video: wc, audio: withMic });
        if (wc) camVideo.srcObject = camStream;
      } catch (camErr) {
        console.warn('camera/mic unavailable, recording screen only:', camErr && camErr.name);
        withCamera = false;
        camStream = null;
      }
    }

    // Stop if the user clicks Chrome's native "stop sharing" bar.
    screenStream.getVideoTracks()[0].onended = () => stop();

    drawLoop();

    const canvasStream = canvas.captureStream(30);
    if (camStream && camStream.getAudioTracks().length) {
      canvasStream.addTrack(camStream.getAudioTracks()[0]);
    }

    step = 'recorder setup';
    const mimeType = pickMimeType(MIME_CANDIDATES, (m) => MediaRecorder.isTypeSupported(m));
    recorder = new MediaRecorder(canvasStream, mimeType ? { mimeType } : undefined);
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = onStop;
    recorder.start(100);
    startedAt = Date.now();
    startTimer();
    statusEl.textContent = 'Recording. Keep this window open (you can move it aside).';
    chrome.runtime.sendMessage({ type: 'RECORDING_STARTED' });
  } catch (e) {
    const error = `${step}: ${(e && e.name) || 'Error'}: ${(e && e.message) || e}`;
    console.warn('recorder start failed:', error, e);
    cleanupStreams();
    chrome.runtime.sendMessage({ type: 'RECORDING_FAILED', error });
  }
}

async function onStop() {
  if (timerId) clearInterval(timerId);
  const type = recorder.mimeType || 'video/webm';
  const blob = new Blob(chunks, { type });
  const filename = makeFilename(new Date());
  cleanupStreams();
  recorder = null;
  statusEl.textContent = 'Saving...';
  try {
    await putRecording(blob, filename);
    chrome.runtime.sendMessage({ type: 'RECORDING_DONE' });
  } catch (e) {
    chrome.runtime.sendMessage({ type: 'RECORDING_FAILED', error: `save: ${(e && e.message) || e}` });
  }
}

function stop() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
}

function setPaused(p) {
  paused = p;
  pauseBtn.textContent = p ? 'Resume' : 'Pause';
}

// Local control buttons route through the background so the on-page toolbar and
// this window stay on one command path.
pauseBtn.addEventListener('click', () => {
  if (!recorder) return;
  chrome.runtime.sendMessage({ type: recorder.state === 'paused' ? 'RESUME' : 'PAUSE' });
});
stopBtn.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'STOP_RECORDING' }));

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.target !== 'recorder') return;
  if (msg.type === 'RECORDER_BUBBLE') bubble = msg.bubblePosition;
  else if (msg.type === 'RECORDER_STOP') stop();
  else if (msg.type === 'RECORDER_PAUSE') { if (recorder && recorder.state === 'recording') { recorder.pause(); setPaused(true); } }
  else if (msg.type === 'RECORDER_RESUME') { if (recorder && recorder.state === 'paused') { recorder.resume(); setPaused(false); } }
});

// On load, read the chosen options and begin.
(async () => {
  const { recParams } = await chrome.storage.local.get('recParams');
  start(recParams || { withCamera: true, withMic: true });
})();
