import { pickMimeType, MIME_CANDIDATES } from './lib/mime.js';
import { bubbleDrawBox } from './lib/composite.js';
import { makeFilename } from './lib/filename.js';
import { putRecording, clearRecording } from './lib/recordingstore.js';

// This page runs in a small visible window. A normal extension window can call
// chrome.desktopCapture (a service worker cannot without tab-anchoring, and an
// offscreen document cannot at all) and it survives main-window tab switches.

const screenVideo = document.getElementById('screen');
const camVideo = document.getElementById('cam');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const statusEl = document.getElementById('status');
const timeEl = document.getElementById('time');
const pauseBtn = document.getElementById('pause');
const stopBtn = document.getElementById('stop');
const countdownEl = document.getElementById('countdown');
const noCamEl = document.getElementById('noCam');

let recorder = null;
let chunks = [];
let rafId = null;
let withCamera = true;
let screenStream = null;
let camStream = null;
let timerId = null;
let startedAt = 0;
let paused = false;

const bubble = { nx: 0.16, ny: 0.82 }; // composited face position (bottom-left of the recording)
const BUBBLE_DIAMETER = 180;

function drawLoop() {
  if (screenVideo.videoWidth) {
    if (canvas.width !== screenVideo.videoWidth) {
      canvas.width = screenVideo.videoWidth;
      canvas.height = screenVideo.videoHeight;
    }
    ctx.drawImage(screenVideo, 0, 0, canvas.width, canvas.height);
    if (withCamera && camVideo.videoWidth) {
      const box = bubbleDrawBox({
        canvasW: canvas.width, canvasH: canvas.height,
        nx: bubble.nx, ny: bubble.ny, diameter: BUBBLE_DIAMETER
      });
      ctx.save();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.clip();
      const vw = camVideo.videoWidth, vh = camVideo.videoHeight;
      const scale = Math.max(box.size / vw, box.size / vh);
      const dw = vw * scale, dh = vh * scale;
      ctx.drawImage(camVideo, box.cx - dw / 2, box.cy - dh / 2, dw, dh);
      ctx.restore();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.stroke();
    }
  }
  rafId = requestAnimationFrame(drawLoop);
}

function fmt(secs) {
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function startTimer() {
  timerId = setInterval(() => {
    if (!paused) timeEl.textContent = fmt(Math.floor((Date.now() - startedAt) / 1000));
  }, 500);
}

function cleanupStreams() {
  cancelAnimationFrame(rafId);
  if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
  if (camStream) camStream.getTracks().forEach((t) => t.stop());
  screenStream = null;
  camStream = null;
}

function runCountdown(n) {
  return new Promise((resolve) => {
    countdownEl.style.display = 'flex';
    countdownEl.textContent = String(n);
    let c = n;
    const iv = setInterval(() => {
      c -= 1;
      if (c < 1) { clearInterval(iv); countdownEl.style.display = 'none'; resolve(); }
      else countdownEl.textContent = String(c);
    }, 700);
  });
}

async function openResult() {
  await chrome.tabs.create({ url: chrome.runtime.getURL('src/result.html') });
  window.close();
}

async function fail(error) {
  cleanupStreams();
  recorder = null;
  try { await clearRecording(); } catch (e) { /* ignore */ }
  await chrome.storage.local.set({ lastError: error });
  await openResult();
}

async function start({ withCamera: wc, withMic, cameraId, micId }) {
  let step = 'screen picker';
  try {
    withCamera = wc;
    statusEl.textContent = 'Choose what to record...';
    const streamId = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (id) => resolve(id));
    });
    if (!streamId) { window.close(); return; } // user dismissed the picker

    step = 'screen capture';
    screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }
    });
    screenVideo.srcObject = screenStream;

    // Camera/mic are non-fatal: if unavailable we still record the screen.
    if (wc || withMic) {
      try {
        camStream = await navigator.mediaDevices.getUserMedia({
          video: wc ? (cameraId ? { deviceId: { ideal: cameraId } } : true) : false,
          audio: withMic ? (micId ? { deviceId: { ideal: micId } } : true) : false
        });
        if (wc) camVideo.srcObject = camStream;
      } catch (camErr) {
        console.warn('camera/mic unavailable:', camErr && camErr.name);
        withCamera = false;
        camStream = null;
      }
    }
    if (!withCamera) noCamEl.style.display = 'flex';

    screenStream.getVideoTracks()[0].onended = () => stop(); // native "stop sharing" bar
    drawLoop();

    const canvasStream = canvas.captureStream(30);
    if (camStream && camStream.getAudioTracks().length) {
      canvasStream.addTrack(camStream.getAudioTracks()[0]);
    }

    step = 'recorder setup';
    const mimeType = pickMimeType(MIME_CANDIDATES, (m) => MediaRecorder.isTypeSupported(m));
    recorder = new MediaRecorder(canvasStream, mimeType ? { mimeType } : undefined);
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = onStop;

    statusEl.textContent = 'Starting...';
    await runCountdown(3);
    recorder.start(100);
    startedAt = Date.now();
    startTimer();
    statusEl.textContent = 'Recording. Keep this window open.';
  } catch (e) {
    await fail(`${step}: ${(e && e.name) || 'Error'}: ${(e && e.message) || e}`);
  }
}

async function onStop() {
  if (timerId) clearInterval(timerId);
  const type = recorder.mimeType || 'video/webm';
  const blob = new Blob(chunks, { type });
  const filename = makeFilename(new Date());
  cleanupStreams();
  recorder = null;
  statusEl.textContent = 'Saving...';
  try {
    await putRecording(blob, filename);
    await chrome.storage.local.remove('lastError');
    await openResult();
  } catch (e) {
    await fail(`save: ${(e && e.message) || e}`);
  }
}

function stop() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
}

pauseBtn.addEventListener('click', () => {
  if (!recorder) return;
  if (recorder.state === 'recording') { recorder.pause(); paused = true; pauseBtn.textContent = 'Resume'; }
  else if (recorder.state === 'paused') { recorder.resume(); paused = false; pauseBtn.textContent = 'Pause'; }
});
stopBtn.addEventListener('click', () => stop());

(async () => {
  const { recParams } = await chrome.storage.local.get('recParams');
  start(recParams || { withCamera: true, withMic: true });
})();
