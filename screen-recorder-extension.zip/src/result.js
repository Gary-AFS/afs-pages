const player = document.getElementById('player');
const download = document.getElementById('download');
const discard = document.getElementById('discard');

const { lastRecording, lastError } = await chrome.storage.local.get(['lastRecording', 'lastError']);

if (lastRecording) {
  player.src = lastRecording.url;
  download.href = lastRecording.url;
  download.setAttribute('download', lastRecording.filename);
  await chrome.storage.local.remove('lastError');
} else {
  // No recording: hide the player/actions/share and show a message.
  player.style.display = 'none';
  document.querySelector('.actions').style.display = 'none';
  document.querySelector('.share').style.display = 'none';
  const h1 = document.querySelector('h1');
  if (lastError) {
    h1.textContent = 'Recording failed';
    const p = document.createElement('p');
    p.style.cssText = 'color:#b91c1c;font-size:14px;background:#fef2f2;border:1px solid #fecaca;padding:16px;border-radius:12px;white-space:pre-wrap;';
    p.textContent = lastError;
    h1.insertAdjacentElement('afterend', p);
  } else {
    h1.textContent = 'No recording found.';
  }
}

discard.addEventListener('click', async () => {
  if (lastRecording) URL.revokeObjectURL(lastRecording.url);
  await chrome.storage.local.remove('lastRecording');
  window.close();
});
