const player = document.getElementById('player');
const download = document.getElementById('download');
const discard = document.getElementById('discard');

const { lastRecording } = await chrome.storage.local.get('lastRecording');

if (lastRecording) {
  player.src = lastRecording.url;
  download.href = lastRecording.url;
  download.setAttribute('download', lastRecording.filename);
} else {
  document.querySelector('h1').textContent = 'No recording found.';
  download.style.display = 'none';
  discard.style.display = 'none';
}

discard.addEventListener('click', async () => {
  if (lastRecording) URL.revokeObjectURL(lastRecording.url);
  await chrome.storage.local.remove('lastRecording');
  window.close();
});
