import { pickMimeType, MIME_CANDIDATES } from './lib/mime.js';
import { bubbleDrawBox } from './lib/composite.js';
import { makeFilename } from './lib/filename.js';

const screenVideo = document.getElementById('screen');
const camVideo = document.getElementById('cam');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

let recorder = null;
let chunks = [];
let rafId = null;
let bubble = { nx: 0.12, ny: 0.82 };
let withCamera = true;
let screenStream = null;
let camStream = null;
let starting = false;

const BUBBLE_DIAMETER = 180;

function drawLoop() {
  if (screenVideo.videoWidth) {
    if (canvas.width !== screenVideo.videoWidth) {
      canvas.width = screenVideo.videoWidth;
      canvas.height = screenVideo.videoHeight;
    }
    ctx.drawImage(screenVideo, 0, 0, canvas.width, canvas.height);
    if (withCamera && camVideo.videoWidth) {
      const box = bubbleDrawBox({
        canvasW: canvas.width, canvasH: canvas.height,
        nx: bubble.nx, ny: bubble.ny, diameter: BUBBLE_DIAMETER
      });
      ctx.save();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.clip();
      const vw = camVideo.videoWidth, vh = camVideo.videoHeight;
      const scale = Math.max(box.size / vw, box.size / vh);
      const dw = vw * scale, dh = vh * scale;
      ctx.drawImage(camVideo, box.cx - dw / 2, box.cy - dh / 2, dw, dh);
      ctx.restore();
      ctx.beginPath();
      ctx.arc(box.cx, box.cy, box.r, 0, Math.PI * 2);
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.stroke();
    }
  }
  rafId = requestAnimationFrame(drawLoop);
}

async function start({ withCamera: wc, withMic, bubblePosition }) {
  if (recorder || starting) return; // guard concurrent / repeat starts
  starting = true;
  let step = 'screen picker';
  try {
    withCamera = wc;
    if (bubblePosition) bubble = bubblePosition;

    if (!chrome.desktopCapture) throw new Error('desktopCapture unavailable in offscreen document');

    // Obtain the desktop stream id HERE, in the offscreen document, so it is
    // created and consumed in the same context. Anchoring it to a tab from the
    // service worker produced "AbortError: Invalid state" when consumed here.
    console.log('[rec] opening screen picker');
    const streamId = await new Promise((resolve) => {
      chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (id) => resolve(id));
    });
    if (!streamId) { // user dismissed the picker
      starting = false;
      chrome.runtime.sendMessage({ type: 'RECORDING_CANCELLED' });
      return;
    }

    step = 'screen capture';
    console.log('[rec] acquiring screen stream');
    screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { mandatory: { chromeMediaSource: 'desktop', chromeMediaSourceId: streamId } }
    });
    console.log('[rec] screen stream acquired');
    screenVideo.srcObject = screenStream;

    // Camera/mic are non-fatal: offscreen pages cannot show a permission prompt,
    // so if the webcam/mic is unavailable we still record the screen.
    if (wc || withMic) {
      try {
        camStream = await navigator.mediaDevices.getUserMedia({ video: wc, audio: withMic });
        console.log('[rec] camera/mic acquired');
        if (wc) camVideo.srcObject = camStream;
      } catch (camErr) {
        console.warn('[rec] camera/mic unavailable, recording screen only:', camErr && camErr.name, camErr && camErr.message);
        withCamera = false;
        camStream = null;
      }
    }

    // Stop if the user clicks Chrome's native "stop sharing" bar.
    screenStream.getVideoTracks()[0].onended = () => stop();

    drawLoop();

    const canvasStream = canvas.captureStream(30);
    if (camStream && camStream.getAudioTracks().length) {
      canvasStream.addTrack(camStream.getAudioTracks()[0]);
    }

    step = 'recorder setup';
    const mimeType = pickMimeType(MIME_CANDIDATES, (m) => MediaRecorder.isTypeSupported(m));
    recorder = new MediaRecorder(canvasStream, mimeType ? { mimeType } : undefined);
    chunks = [];
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = onStop;
    recorder.start(100);
    starting = false;
    console.log('[rec] MediaRecorder started');
    chrome.runtime.sendMessage({ type: 'RECORDING_STARTED' });
  } catch (e) {
    starting = false;
    const error = `${step}: ${(e && e.name) || 'Error'}: ${(e && e.message) || e}`;
    console.warn('offscreen start failed:', error, e);
    cancelAnimationFrame(rafId);
    if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
    if (camStream) camStream.getTracks().forEach((t) => t.stop());
    screenStream = null; camStream = null; recorder = null;
    chrome.runtime.sendMessage({ type: 'RECORDING_FAILED', error });
  }
}

function onStop() {
  const type = recorder.mimeType || 'video/webm';
  const blob = new Blob(chunks, { type });
  const url = URL.createObjectURL(blob);
  const filename = makeFilename(new Date());

  cancelAnimationFrame(rafId);
  if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
  if (camStream) camStream.getTracks().forEach((t) => t.stop());
  screenStream = null; camStream = null; recorder = null;

  // The offscreen document stays alive, so this blob URL remains valid for the
  // result tab (same extension origin) to load. The service worker owns tab/storage.
  chrome.runtime.sendMessage({ type: 'RECORDING_DONE', url, filename });
}

function stop() {
  if (recorder && recorder.state !== 'inactive') recorder.stop();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.target !== 'offscreen') return;
  if (msg.type === 'OFFSCREEN_START') start(msg); // start() self-guards
  else if (msg.type === 'OFFSCREEN_STOP') stop();
  else if (msg.type === 'OFFSCREEN_BUBBLE') bubble = msg.bubblePosition;
  else if (msg.type === 'OFFSCREEN_PAUSE') { if (recorder && recorder.state === 'recording') recorder.pause(); }
  else if (msg.type === 'OFFSCREEN_RESUME') { if (recorder && recorder.state === 'paused') recorder.resume(); }
});
