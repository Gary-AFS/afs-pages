// Injected on every page. Shows a single draggable webcam head while a recording
// is active (driven by chrome.storage flags set by the recorder window). The head
// is a real DOM element on the page, so the screen capture films it exactly where
// the user drags it. Camera access uses the page origin (a one-time per-site prompt).

(() => {
  const HEAD_ID = 'afs-rec-head';
  const DOT_ID = 'afs-rec-dot';
  const CTRL_PAD = 56; // room kept below the head so the pause/stop bar stays on-screen
  let wrap = null;
  let camStream = null;
  let dragging = false;
  let ox = 0;
  let oy = 0;
  let recording = false;
  let dotOn = false; // red cursor spotlight (annotation) toggle
  const lastMouse = { x: 0, y: 0 };

  // deviceId is origin-scoped, so the id chosen in the popup is meaningless here.
  // Match the requested camera by LABEL (stable across origins) at the page origin.
  async function selectCamera(video, cameraLabel) {
    try {
      let stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      if (cameraLabel) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const match = devices.find((d) => d.kind === 'videoinput' && d.label === cameraLabel);
        const currentId = stream.getVideoTracks()[0].getSettings().deviceId;
        if (match && match.deviceId && match.deviceId !== currentId) {
          stream.getTracks().forEach((t) => t.stop());
          stream = await navigator.mediaDevices.getUserMedia({
            video: { deviceId: { exact: match.deviceId } }, audio: false
          });
        }
      }
      camStream = stream;
      video.srcObject = stream;
    } catch (e) {
      const camEl = video.closest('.afs-head-cam');
      if (camEl) camEl.style.background = '#334155'; // camera blocked: neutral head, recording unaffected
    }
  }

  // Relay a pause/resume/stop command to the recorder window via storage (same
  // channel the extension-icon popup uses).
  function sendCommand(action) {
    chrome.storage.local.set({ command: { action, n: Date.now() } });
  }
  function updatePauseLabel(isPaused) {
    const b = document.querySelector('#' + HEAD_ID + ' .afs-hc-pause');
    if (b) b.textContent = isPaused ? 'Resume' : 'Pause';
  }

  // --- Red cursor spotlight: a glowing dot that tracks the mouse, toggled from
  // the head control bar. It IS part of the recording (that's the point), so it
  // only exists while a recording is running and the toggle is on.
  function ensureDot() {
    let d = document.getElementById(DOT_ID);
    if (!d) {
      d = document.createElement('div');
      d.id = DOT_ID;
      document.documentElement.appendChild(d);
    }
    d.style.transform = `translate(${lastMouse.x - 11}px, ${lastMouse.y - 11}px)`;
  }
  function removeDot() {
    const d = document.getElementById(DOT_ID);
    if (d) d.remove();
  }
  function applyDot() {
    if (recording && dotOn) ensureDot();
    else removeDot();
  }
  function updateDotBtn() {
    const b = document.querySelector('#' + HEAD_ID + ' .afs-hc-dot');
    if (b) b.classList.toggle('active', dotOn);
  }

  function ensureHead(cameraLabel, pos) {
    if (document.getElementById(HEAD_ID)) return;

    wrap = document.createElement('div');
    wrap.id = HEAD_ID;

    // Round camera tile (clipped) holding the live video and the drag surface.
    const cam = document.createElement('div');
    cam.className = 'afs-head-cam';
    const video = document.createElement('video');
    video.autoplay = true;
    video.muted = true;
    video.playsInline = true;
    cam.appendChild(video);

    const drag = document.createElement('div');
    drag.className = 'afs-drag';
    drag.addEventListener('mousedown', onDown);
    cam.appendChild(drag);
    wrap.appendChild(cam);

    // Control bar attached under the head: Pause, Stop, and the cursor-highlight
    // toggle. Semi-transparent at rest so people know it's there, fully solid on
    // hover.
    const ctrl = document.createElement('div');
    ctrl.className = 'afs-head-ctrl';
    const pauseBtn = document.createElement('button');
    pauseBtn.className = 'afs-hc-pause';
    pauseBtn.textContent = 'Pause';
    const stopBtn = document.createElement('button');
    stopBtn.className = 'afs-hc-stop';
    stopBtn.textContent = 'Stop';
    const dotBtn = document.createElement('button');
    dotBtn.className = 'afs-hc-dot';
    dotBtn.textContent = 'Cursor';
    dotBtn.title = 'Highlight my cursor with a red dot';
    ctrl.appendChild(pauseBtn);
    ctrl.appendChild(stopBtn);
    ctrl.appendChild(dotBtn);
    wrap.appendChild(ctrl);

    const swallow = (e) => e.stopPropagation(); // don't let a button start a drag
    [pauseBtn, stopBtn, dotBtn].forEach((b) => b.addEventListener('mousedown', swallow));
    pauseBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const { paused } = await chrome.storage.local.get('paused');
      sendCommand(paused ? 'resume' : 'pause');
    });
    stopBtn.addEventListener('click', (e) => { e.stopPropagation(); sendCommand('stop'); });
    dotBtn.addEventListener('click', (e) => { e.stopPropagation(); chrome.storage.local.set({ dotOn: !dotOn }); });

    wrap.style.left = (pos && pos.left != null ? pos.left : 24) + 'px';
    wrap.style.top = (pos && pos.top != null ? pos.top : Math.max(0, window.innerHeight - 160 - CTRL_PAD - 24)) + 'px';
    document.documentElement.appendChild(wrap);
    updateDotBtn();

    selectCamera(video, cameraLabel);
  }

  function removeHead() {
    if (camStream) { camStream.getTracks().forEach((t) => t.stop()); camStream = null; }
    const el = document.getElementById(HEAD_ID);
    if (el) el.remove();
    wrap = null;
  }

  function onDown(e) {
    if (!wrap) return;
    dragging = true;
    ox = e.clientX - wrap.offsetLeft;
    oy = e.clientY - wrap.offsetTop;
    e.preventDefault();
  }
  function onMove(e) {
    if (!dragging || !wrap) return;
    const left = Math.max(0, Math.min(window.innerWidth - wrap.offsetWidth, e.clientX - ox));
    const top = Math.max(0, Math.min(window.innerHeight - wrap.offsetHeight - CTRL_PAD, e.clientY - oy));
    wrap.style.left = left + 'px';
    wrap.style.top = top + 'px';
  }
  function onUp() {
    if (!dragging || !wrap) return;
    dragging = false;
    chrome.storage.local.set({ headPos: { left: wrap.offsetLeft, top: wrap.offsetTop } });
  }
  window.addEventListener('mousemove', onMove, true);
  window.addEventListener('mouseup', onUp, true);
  window.addEventListener('mousemove', (e) => {
    lastMouse.x = e.clientX;
    lastMouse.y = e.clientY;
    if (recording && dotOn) {
      const d = document.getElementById(DOT_ID);
      if (d) d.style.transform = `translate(${e.clientX - 11}px, ${e.clientY - 11}px)`;
    }
  }, true);

  // Big, obvious 3-2-1 overlay painted on the page itself, driven by the `countdown`
  // storage flag the recorder window sets. It clears before recording starts, so it
  // never appears in the actual video.
  const COUNTDOWN_ID = 'afs-rec-countdown';
  function showCountdown(n) {
    let el = document.getElementById(COUNTDOWN_ID);
    if (!n || n < 1) { if (el) el.remove(); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = COUNTDOWN_ID;
      const lbl = document.createElement('div');
      lbl.className = 'afs-cd-lbl';
      lbl.textContent = 'Recording starts in';
      const num = document.createElement('div');
      num.className = 'afs-cd-num';
      el.appendChild(lbl);
      el.appendChild(num);
      document.documentElement.appendChild(el);
    }
    const num = el.querySelector('.afs-cd-num');
    num.textContent = n;
    num.style.animation = 'none';
    void num.offsetWidth; // reflow, so the pop animation re-fires each tick
    num.style.animation = '';
  }

  async function sync() {
    const st = await chrome.storage.local.get(['recording', 'headOn', 'headCamLabel', 'headPos', 'dotOn']);
    recording = !!st.recording;
    dotOn = !!st.dotOn;
    if (recording && st.headOn !== false) ensureHead(st.headCamLabel, st.headPos);
    else removeHead();
    applyDot();
    updateDotBtn();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.recording || changes.headOn || changes.headCamLabel) sync();
    if (changes.paused) updatePauseLabel(changes.paused.newValue);
    if (changes.dotOn) { dotOn = !!changes.dotOn.newValue; applyDot(); updateDotBtn(); }
    if (changes.countdown) showCountdown(changes.countdown.newValue);
    // Safety net: if recording ends (incl. mid-countdown failure), kill the overlay.
    if (changes.recording && changes.recording.newValue === false) showCountdown(0);
  });

  sync();
})();
