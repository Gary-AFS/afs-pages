// Injected on every page. Shows a single draggable webcam head while a recording
// is active (driven by chrome.storage flags set by the recorder window). The head
// is a real DOM element on the page, so the screen capture films it exactly where
// the user drags it. Camera access uses the page origin (a one-time per-site prompt).

(() => {
  const HEAD_ID = 'afs-rec-head';
  let wrap = null;
  let camStream = null;
  let dragging = false;
  let ox = 0;
  let oy = 0;

  // deviceId is origin-scoped, so the id chosen in the popup is meaningless here.
  // Match the requested camera by LABEL (stable across origins) at the page origin.
  async function selectCamera(video, cameraLabel) {
    try {
      let stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      if (cameraLabel) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const match = devices.find((d) => d.kind === 'videoinput' && d.label === cameraLabel);
        const currentId = stream.getVideoTracks()[0].getSettings().deviceId;
        if (match && match.deviceId && match.deviceId !== currentId) {
          stream.getTracks().forEach((t) => t.stop());
          stream = await navigator.mediaDevices.getUserMedia({
            video: { deviceId: { exact: match.deviceId } }, audio: false
          });
        }
      }
      camStream = stream;
      video.srcObject = stream;
    } catch (e) {
      if (wrap) wrap.style.background = '#334155'; // camera blocked: neutral head, recording unaffected
    }
  }

  function ensureHead(cameraLabel, pos) {
    if (document.getElementById(HEAD_ID)) return;

    wrap = document.createElement('div');
    wrap.id = HEAD_ID;

    const video = document.createElement('video');
    video.autoplay = true;
    video.muted = true;
    video.playsInline = true;
    wrap.appendChild(video);

    const drag = document.createElement('div');
    drag.className = 'afs-drag';
    drag.addEventListener('mousedown', onDown);
    wrap.appendChild(drag);

    wrap.style.left = (pos && pos.left != null ? pos.left : 24) + 'px';
    wrap.style.top = (pos && pos.top != null ? pos.top : Math.max(0, window.innerHeight - 200)) + 'px';
    document.documentElement.appendChild(wrap);

    selectCamera(video, cameraLabel);
  }

  function removeHead() {
    if (camStream) { camStream.getTracks().forEach((t) => t.stop()); camStream = null; }
    const el = document.getElementById(HEAD_ID);
    if (el) el.remove();
    wrap = null;
  }

  function onDown(e) {
    if (!wrap) return;
    dragging = true;
    ox = e.clientX - wrap.offsetLeft;
    oy = e.clientY - wrap.offsetTop;
    e.preventDefault();
  }
  function onMove(e) {
    if (!dragging || !wrap) return;
    const left = Math.max(0, Math.min(window.innerWidth - wrap.offsetWidth, e.clientX - ox));
    const top = Math.max(0, Math.min(window.innerHeight - wrap.offsetHeight, e.clientY - oy));
    wrap.style.left = left + 'px';
    wrap.style.top = top + 'px';
  }
  function onUp() {
    if (!dragging || !wrap) return;
    dragging = false;
    chrome.storage.local.set({ headPos: { left: wrap.offsetLeft, top: wrap.offsetTop } });
  }
  window.addEventListener('mousemove', onMove, true);
  window.addEventListener('mouseup', onUp, true);

  async function sync() {
    const { recording, headOn, headCamLabel, headPos } =
      await chrome.storage.local.get(['recording', 'headOn', 'headCamLabel', 'headPos']);
    if (recording && headOn !== false) ensureHead(headCamLabel, headPos);
    else removeHead();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.recording || changes.headOn || changes.headCamLabel) sync();
  });

  sync();
})();
