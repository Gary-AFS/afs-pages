(() => {
  if (window.__afsRecInjected) return; // already injected in this tab
  window.__afsRecInjected = true;

  let camStream = null;
  let startTs = Date.now();
  let paused = false;
  let timerId = null;
  let mounted = false;

  const bubble = document.createElement('div');
  bubble.id = 'afs-rec-bubble';
  const vid = document.createElement('video');
  vid.autoplay = true; vid.muted = true; vid.playsInline = true;
  bubble.appendChild(vid);

  const bar = document.createElement('div');
  bar.id = 'afs-rec-bar';
  const dot = document.createElement('span'); dot.className = 'dot';
  const time = document.createElement('span'); time.textContent = '00:00';
  const pauseBtn = document.createElement('button'); pauseBtn.textContent = 'Pause';
  const stopBtn = document.createElement('button'); stopBtn.textContent = 'Stop';
  bar.append(dot, time, pauseBtn, stopBtn);

  function place(nx, ny) {
    const x = nx * window.innerWidth - bubble.offsetWidth / 2;
    const y = ny * window.innerHeight - bubble.offsetHeight / 2;
    bubble.style.left = Math.max(0, Math.min(window.innerWidth - bubble.offsetWidth, x)) + 'px';
    bubble.style.top = Math.max(0, Math.min(window.innerHeight - bubble.offsetHeight, y)) + 'px';
  }

  function report() {
    const cx = bubble.offsetLeft + bubble.offsetWidth / 2;
    const cy = bubble.offsetTop + bubble.offsetHeight / 2;
    chrome.runtime.sendMessage({
      type: 'BUBBLE_MOVED',
      bubblePosition: { nx: cx / window.innerWidth, ny: cy / window.innerHeight }
    });
  }

  let dragging = false, ox = 0, oy = 0;
  function onMouseDown(e) {
    dragging = true; ox = e.clientX - bubble.offsetLeft; oy = e.clientY - bubble.offsetTop;
    bubble.style.cursor = 'grabbing';
  }
  function onMouseMove(e) {
    if (!dragging) return;
    bubble.style.left = Math.max(0, Math.min(window.innerWidth - bubble.offsetWidth, e.clientX - ox)) + 'px';
    bubble.style.top = Math.max(0, Math.min(window.innerHeight - bubble.offsetHeight, e.clientY - oy)) + 'px';
    report();
  }
  function onMouseUp() { dragging = false; bubble.style.cursor = 'grab'; }
  bubble.addEventListener('mousedown', onMouseDown);
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);

  function tick() {
    const secs = Math.max(0, Math.floor((Date.now() - startTs) / 1000));
    const m = String(Math.floor(secs / 60)).padStart(2, '0');
    const s = String(secs % 60).padStart(2, '0');
    time.textContent = `${m}:${s}`;
  }

  function cleanup() {
    if (timerId) clearInterval(timerId);
    if (camStream) camStream.getTracks().forEach((t) => t.stop());
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    bubble.remove(); bar.remove();
    mounted = false;
    window.__afsRecInjected = false;
  }

  pauseBtn.addEventListener('click', () => {
    paused = !paused;
    pauseBtn.textContent = paused ? 'Resume' : 'Pause';
    chrome.runtime.sendMessage({ type: paused ? 'PAUSE' : 'RESUME' });
  });
  stopBtn.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'STOP_RECORDING' }));

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SHOW_CONTROLS') {
      if (mounted) return;
      mounted = true;
      const p = msg.bubblePosition || { nx: 0.12, ny: 0.82 };
      startTs = msg.startTs || Date.now();
      document.documentElement.append(bubble, bar);
      if (msg.withCamera) {
        // Defer one frame so layout has run and offsetWidth/Height are correct.
        requestAnimationFrame(() => place(p.nx, p.ny));
        navigator.mediaDevices.getUserMedia({ video: true })
          .then((s) => { camStream = s; vid.srcObject = s; })
          .catch(() => { bubble.style.background = '#334155'; }); // graceful: neutral bubble if camera blocked
      } else {
        bubble.style.display = 'none'; // no camera bubble when the user disabled it
      }
      timerId = setInterval(tick, 1000);
      tick();
    } else if (msg.type === 'HIDE_CONTROLS') {
      cleanup();
    }
  });
})();
