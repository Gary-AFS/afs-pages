const setupView = document.getElementById('setupView');
const recordingView = document.getElementById('recordingView');

// Setup controls
const cam = document.getElementById('cam');
const mic = document.getElementById('mic');
const cameraSelect = document.getElementById('cameraSelect');
const micSelect = document.getElementById('micSelect');
const enableBtn = document.getElementById('enable');
const start = document.getElementById('start');

// Recording controls
const recTime = document.getElementById('recTime');
const recState = document.getElementById('recState');
const popPause = document.getElementById('popPause');
const popStop = document.getElementById('popStop');

let timerId = null;

// ---------- device setup ----------
function fillSelect(select, devices, kind, fallbackLabel) {
  const current = select.value;
  select.innerHTML = '';
  const list = devices.filter((d) => d.kind === kind);
  if (!list.length) {
    const o = document.createElement('option');
    o.value = ''; o.textContent = 'Default';
    select.appendChild(o);
    return;
  }
  for (const d of list) {
    const o = document.createElement('option');
    o.value = d.deviceId;
    o.textContent = d.label || fallbackLabel;
    select.appendChild(o);
  }
  if (current) select.value = current;
}

async function loadDevices() {
  const devices = await navigator.mediaDevices.enumerateDevices();
  const hasLabels = devices.some((d) => d.label);
  fillSelect(cameraSelect, devices, 'videoinput', 'Camera');
  fillSelect(micSelect, devices, 'audioinput', 'Microphone');
  enableBtn.hidden = hasLabels;
}

enableBtn.addEventListener('click', async () => {
  try {
    const s = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    s.getTracks().forEach((t) => t.stop());
    await loadDevices();
  } catch (e) { /* denied */ }
});

function applyState() {
  cameraSelect.disabled = !cam.checked;
  micSelect.disabled = !mic.checked;
}

cam.addEventListener('change', () => { chrome.storage.local.set({ withCamera: cam.checked }); applyState(); });
mic.addEventListener('change', () => { chrome.storage.local.set({ withMic: mic.checked }); applyState(); });
cameraSelect.addEventListener('change', () => chrome.storage.local.set({
  cameraId: cameraSelect.value,
  cameraLabel: cameraSelect.selectedOptions[0] ? cameraSelect.selectedOptions[0].textContent : ''
}));
micSelect.addEventListener('change', () => chrome.storage.local.set({ micId: micSelect.value }));

start.addEventListener('click', async () => {
  const recParams = {
    withCamera: cam.checked,
    withMic: mic.checked,
    cameraLabel: cam.checked && cameraSelect.selectedOptions[0] ? cameraSelect.selectedOptions[0].textContent : '',
    micId: mic.checked ? micSelect.value : ''
  };
  await chrome.storage.local.set({ recParams });
  // Open large and centred (NOT maximised) so Chrome's "choose what to record"
  // picker is big and easy to use, while staying in 'normal' window state so
  // recorder.js can reliably shrink it to the slim toolbar once a surface is
  // chosen. (Maximised windows don't un-maximise cleanly, so they'd stay full
  // screen and cover the on-page countdown.)
  const W = 840, H = 600;
  await chrome.windows.create({
    url: chrome.runtime.getURL('src/recorder.html'),
    type: 'popup',
    width: W,
    height: H,
    left: Math.max(0, Math.round((screen.availWidth - W) / 2)),
    top: Math.max(0, Math.round((screen.availHeight - H) / 2)),
    focused: true
  });
  window.close();
});

// ---------- recording controls ----------
function fmt(secs) {
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function renderRecording(startedAt, paused) {
  popPause.textContent = paused ? 'Resume' : 'Pause';
  recState.textContent = paused ? 'Paused' : 'Recording';
  if (timerId) clearInterval(timerId);
  const tick = () => { recTime.textContent = fmt(Math.floor((Date.now() - (startedAt || Date.now())) / 1000)); };
  tick();
  timerId = setInterval(tick, 500);
}

function sendCommand(action) {
  chrome.storage.local.set({ command: { action, n: Date.now() } });
}

popPause.addEventListener('click', async () => {
  const { paused } = await chrome.storage.local.get('paused');
  sendCommand(paused ? 'resume' : 'pause');
});
popStop.addEventListener('click', () => sendCommand('stop'));

async function decideView() {
  const { recording, startedAt, paused } = await chrome.storage.local.get(['recording', 'startedAt', 'paused']);
  if (recording) {
    setupView.hidden = true;
    recordingView.hidden = false;
    renderRecording(startedAt, paused);
  } else {
    setupView.hidden = false;
    recordingView.hidden = true;
    if (timerId) clearInterval(timerId);
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.recording) {
    if (changes.recording.newValue) decideView();
    else window.close(); // recording ended; result tab opens from the recorder
  }
  if (changes.paused && !recordingView.hidden) {
    const p = changes.paused.newValue;
    popPause.textContent = p ? 'Resume' : 'Pause';
    recState.textContent = p ? 'Paused' : 'Recording';
  }
});

// ---------- init ----------
(async () => {
  const s = await chrome.storage.local.get(['withCamera', 'withMic', 'cameraId', 'micId']);
  if (typeof s.withCamera === 'boolean') cam.checked = s.withCamera;
  if (typeof s.withMic === 'boolean') mic.checked = s.withMic;
  await loadDevices();
  if (s.cameraId) cameraSelect.value = s.cameraId;
  if (s.micId) micSelect.value = s.micId;
  applyState();
  await decideView();
})();
