const cam = document.getElementById('cam');
const mic = document.getElementById('mic');
const cameraSelect = document.getElementById('cameraSelect');
const micSelect = document.getElementById('micSelect');
const enableBtn = document.getElementById('enable');
const start = document.getElementById('start');

function fill(select, devices, kind, fallbackLabel) {
  const current = select.value;
  select.innerHTML = '';
  const list = devices.filter((d) => d.kind === kind);
  if (!list.length) {
    const o = document.createElement('option');
    o.value = ''; o.textContent = 'Default';
    select.appendChild(o);
    return;
  }
  for (const d of list) {
    const o = document.createElement('option');
    o.value = d.deviceId;
    o.textContent = d.label || fallbackLabel;
    select.appendChild(o);
  }
  if (current) select.value = current;
}

async function loadDevices() {
  const devices = await navigator.mediaDevices.enumerateDevices();
  const hasLabels = devices.some((d) => d.label);
  fill(cameraSelect, devices, 'videoinput', 'Camera');
  fill(micSelect, devices, 'audioinput', 'Microphone');
  enableBtn.hidden = hasLabels; // only offer "allow" while labels are hidden
}

enableBtn.addEventListener('click', async () => {
  try {
    const s = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    s.getTracks().forEach((t) => t.stop());
    await loadDevices();
  } catch (e) {
    // permission denied; leave generic labels
  }
});

function applyState() {
  cameraSelect.disabled = !cam.checked;
  micSelect.disabled = !mic.checked;
}

cam.addEventListener('change', () => { chrome.storage.local.set({ withCamera: cam.checked }); applyState(); });
mic.addEventListener('change', () => { chrome.storage.local.set({ withMic: mic.checked }); applyState(); });
cameraSelect.addEventListener('change', () => chrome.storage.local.set({ cameraId: cameraSelect.value }));
micSelect.addEventListener('change', () => chrome.storage.local.set({ micId: micSelect.value }));

start.addEventListener('click', async () => {
  const recParams = {
    withCamera: cam.checked,
    withMic: mic.checked,
    cameraId: cam.checked ? cameraSelect.value : '',
    micId: mic.checked ? micSelect.value : ''
  };
  await chrome.storage.local.set({ recParams });
  await chrome.windows.create({
    url: chrome.runtime.getURL('src/recorder.html'),
    type: 'popup', width: 300, height: 400, focused: true
  });
  window.close();
});

(async () => {
  const s = await chrome.storage.local.get(['withCamera', 'withMic', 'cameraId', 'micId']);
  if (typeof s.withCamera === 'boolean') cam.checked = s.withCamera;
  if (typeof s.withMic === 'boolean') mic.checked = s.withMic;
  await loadDevices();
  if (s.cameraId) cameraSelect.value = s.cameraId;
  if (s.micId) micSelect.value = s.micId;
  applyState();
})();
