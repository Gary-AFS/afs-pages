const cam = document.getElementById('cam');
const mic = document.getElementById('mic');
const start = document.getElementById('start');

chrome.storage.local.get(['withCamera', 'withMic']).then((s) => {
  if (typeof s.withCamera === 'boolean') cam.checked = s.withCamera;
  if (typeof s.withMic === 'boolean') mic.checked = s.withMic;
});

cam.addEventListener('change', () => chrome.storage.local.set({ withCamera: cam.checked }));
mic.addEventListener('change', () => chrome.storage.local.set({ withMic: mic.checked }));

start.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({
    type: 'START_RECORDING',
    withCamera: cam.checked,
    withMic: mic.checked
  });
  window.close();
});
